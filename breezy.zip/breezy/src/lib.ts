import { useEffect, useState } from "react";
import type { NavItem, Prefs, Provider, RoleKey, Usage, View } from "./types";

export const MAIN_NAV: NavItem[] = [
  { id: "chat", label: "Chat", icon: "chat_bubble" },
  { id: "research", label: "Research", icon: "psychology" },
  { id: "history", label: "History", icon: "history" },
  { id: "models", label: "Models", icon: "hub" },
  { id: "docs", label: "Docs", icon: "menu_book" },
  { id: "settings", label: "Settings", icon: "settings" },
];
export const LAB_NAV: NavItem[] = [
  { id: "build", label: "Build", icon: "terminal" },
  { id: "canvas", label: "Canvas", icon: "draw" },
];
export const TABS: NavItem[] = [MAIN_NAV[0], MAIN_NAV[1], MAIN_NAV[3], MAIN_NAV[4], MAIN_NAV[5]];
export const TITLES: Record<View, string> = {
  chat: "Chat", research: "Research", history: "History", models: "Models",
  docs: "Docs", settings: "Settings", build: "Build", canvas: "Canvas",
};

export const PRESETS = [
  { id: "groq", label: "Groq", baseUrl: "https://api.groq.com/openai/v1", needsKey: true },
  { id: "openrouter", label: "OpenRouter", baseUrl: "https://openrouter.ai/api/v1", needsKey: true },
  { id: "gemini", label: "Google Gemini", baseUrl: "https://generativelanguage.googleapis.com/v1beta/openai", needsKey: true },
  { id: "sambanova", label: "SambaNova", baseUrl: "https://api.sambanova.ai/v1", needsKey: true },
  { id: "ollama", label: "Ollama (local)", baseUrl: "http://localhost:11434/v1", needsKey: false },
  { id: "custom", label: "Custom OpenAI-compatible", baseUrl: "", needsKey: false },
];

export const LS = {
  providers: "breezy.providers",
  active: "breezy.active",
  convs: "breezy.convs",
  runs: "breezy.runs",
  roles: "breezy.roles",
  prefs: "breezy.prefs",
};

export const DEFAULT_PREFS: Prefs = { showMeta: true, enterToSend: true };

export const ROLE_LABEL: Record<RoleKey, string> = {
  solo: "Solo", analyst: "Analyst", critic: "Critic", synth: "Synthesizer",
};
export const ROLE_HINT: Record<RoleKey, string> = {
  solo: "Answers the question directly in one pass.",
  analyst: "Breaks the question down and states findings and assumptions.",
  critic: "Challenges the Analyst: gaps, weak claims, missing cases.",
  synth: "Reconciles both into a final answer with open questions.",
};

export const uid = () => Math.random().toString(36).slice(2, 9) + Date.now().toString(36);

export function useStore<T>(key: string, init: T, fix?: (v: T) => T) {
  const [v, setV] = useState<T>(() => {
    try {
      const s = localStorage.getItem(key);
      if (!s) return init;
      const parsed = JSON.parse(s) as T;
      return fix ? fix(parsed) : parsed;
    } catch {
      return init;
    }
  });
  useEffect(() => {
    try { localStorage.setItem(key, JSON.stringify(v)); } catch {}
  }, [key, v]);
  return [v, setV] as const;
}

export function isLocal(url: string) {
  try {
    const h = new URL(url).hostname;
    return h === "localhost" || h === "127.0.0.1" || h === "[::1]" || h === "::1" || h.endsWith(".local");
  } catch {
    return false;
  }
}

export const usable = (p?: Provider | null): p is Provider => !!p && !!p.baseUrl && !!p.model;

export const fmtUsage = (u?: Usage) =>
  u && (u.prompt != null || u.completion != null)
    ? `${u.prompt ?? "?"} in / ${u.completion ?? "?"} out`
    : "Not reported";

export const fmtMs = (ms?: number) =>
  ms == null ? "Unknown" : ms < 1000 ? `${ms} ms` : `${(ms / 1000).toFixed(1)} s`;

export function fmtWhen(t?: number) {
  if (!t) return "Unknown";
  const d = new Date(t);
  const now = new Date();
  const same = d.toDateString() === now.toDateString();
  const time = d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  return same ? `Today, ${time}` : `${d.toLocaleDateString([], { day: "numeric", month: "short" })}, ${time}`;
}

export function friendlyError(e: any) {
  const m = String(e?.message ?? e);
  if (m.includes("Failed to fetch") || m.includes("NetworkError") || m.includes("Load failed"))
    return "Network or CORS error. Check the endpoint URL. For Ollama, start it with OLLAMA_ORIGINS set to allow this site.";
  return m;
}

/* ───────────── Provider API (OpenAI-compatible) ───────────── */

function headers(p: Provider) {
  const h: Record<string, string> = { "Content-Type": "application/json" };
  if (p.apiKey) h.Authorization = `Bearer ${p.apiKey}`;
  return h;
}

export async function testProvider(p: Provider): Promise<{ ok: boolean; models: string[]; error?: string }> {
  try {
    const res = await fetch(p.baseUrl.replace(/\/+$/, "") + "/models", { headers: headers(p) });
    if (!res.ok) return { ok: false, models: [], error: `HTTP ${res.status}. Check the key and endpoint.` };
    const j = await res.json();
    const list: string[] = (j.data ?? j.models ?? [])
      .map((m: any) => String(m.id ?? m.name ?? ""))
      .filter(Boolean)
      .sort();
    return { ok: true, models: list };
  } catch (e) {
    return { ok: false, models: [], error: friendlyError(e) };
  }
}

export async function streamChat(
  p: Provider,
  messages: { role: string; content: string }[],
  onDelta: (t: string) => void,
  signal: AbortSignal
): Promise<{ ms: number; usage?: Usage }> {
  const t0 = performance.now();
  const url = p.baseUrl.replace(/\/+$/, "") + "/chat/completions";
  const post = (withUsage: boolean) =>
    fetch(url, {
      method: "POST",
      signal,
      headers: headers(p),
      body: JSON.stringify({
        model: p.model,
        messages,
        stream: true,
        ...(withUsage ? { stream_options: { include_usage: true } } : {}),
      }),
    });
  // Asks for token usage. Some providers reject stream_options, so retry once without it.
  let res = await post(true);
  if (res.status === 400 || res.status === 422) res = await post(false);
  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`HTTP ${res.status}. ${t.slice(0, 240)}`);
  }
  if (!res.body) throw new Error("No response stream from provider.");
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = "";
  let usage: Usage | undefined;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    const lines = buf.split("\n");
    buf = lines.pop() ?? "";
    for (const line of lines) {
      const l = line.trim();
      if (!l.startsWith("data:")) continue;
      const d = l.slice(5).trim();
      if (!d || d === "[DONE]") continue;
      try {
        const j = JSON.parse(d);
        const delta = j.choices?.[0]?.delta?.content;
        if (delta) onDelta(delta);
        const u = j.usage ?? j.x_groq?.usage;
        if (u) usage = { prompt: u.prompt_tokens, completion: u.completion_tokens };
      } catch {}
    }
  }
  return { ms: Math.round(performance.now() - t0), usage };
}

export function storageBytes() {
  let n = 0;
  try {
    for (const k of Object.values(LS)) n += (localStorage.getItem(k) ?? "").length * 2;
  } catch {}
  return n;
}
export const fmtBytes = (n: number) =>
  n < 1024 ? `${n} B` : n < 1024 * 1024 ? `${(n / 1024).toFixed(1)} KB` : `${(n / 1024 / 1024).toFixed(2)} MB`;
